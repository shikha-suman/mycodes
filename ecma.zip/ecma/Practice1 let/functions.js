"use strict";


//anonymous function
var f = function() { return "hello" }
console.log(f())

//default function parameter

function add(a, b = 6) {
    return a + b;
}
console.log(add(4))

//recursion

function factorial(num) {
    if (num <= 0) {
        return 1;
    } else {
        return (num * factorial(num - 1))
    }
}
console.log(factorial(10))