"use strict"

function addNumbers(a, b, c) {
    console.log(a + b + c);
}

var nums = [3, 4, 5];
//addNumbers(num[0], nums[1], num[2]);

addNumbers(...nums); //spread operator


//combine array using spread operator
var item1 = ['idli', 'dosa'];
var food = ['apples', ...item1, 'oranges', 'pineapples'];
console.log(food);



function fun1(...params) {
    console.log(params.length);
}
fun1();
fun1(5);
fun1(5, 6, 7);