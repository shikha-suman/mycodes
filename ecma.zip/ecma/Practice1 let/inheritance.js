"use strict"

class Person {
    constructor(name, age, weight) {
        this.name = name;
        this.age = age;
        this.weight = weight;
    }
    displayName() {
        console.log(this.name);
    }
    displayAge() {
        console.log(this.age);
    }



    displayWeight() {
        console.log(this.weight);
    }

}


class Programmer extends Person {

    constructor(name, age, weight, language) {
        super(name, age, weight);
        this.language = language;
    }
}

let shikha = new Person('Shikha', 23, 23424);
shikha.displayName();
shikha.displayAge();
shikha.displayWeight();

console.log('-----------');

let suman = new Programmer('Suman', 43, 432, 'javascript');
suman.displayName();
suman.displayAge();