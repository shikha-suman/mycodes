"use strict"

class Person {
    constructor(name, age, weight) {
        this.name = name;
        this.age = age;
        this.weight = weight;
    }

    displayWeight() {
        console.log(this.weight);
    }
    displayAge() {
        console.log(this.age);
    }
}

let shikha = new Person('Shikha', 23, 23424);
let suman = new Person('Suman', 34, 2312);

shikha.displayWeight();
suman.displayAge();

//super-->child class can invoke its parent class data member
class PrinterClass {
    doPrint() {
        console.log("doPrint() from Parent called…")
    }
}
class StringPrinter extends PrinterClass {
    doPrint() {
        super.doPrint()
        console.log("doPrint() is printing a string…")
    }
}
var obj = new StringPrinter()
obj.doPrint()