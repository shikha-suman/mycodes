"use strict";

let name = 'Shikha';

console.log('My favourite person is ' + name + ' because she is good.');
console.log(`My favourite person is ${name} because she is good`); //backticks

let a = 5;
let b = 7;
console.log(`My favourite person is ${a+b} 
because she is good`); //new line