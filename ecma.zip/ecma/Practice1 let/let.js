"use strict";

let movie = 'Hello everyone';
const song = "hello"

function theNotebook() {
    let movie = 'The Notebook';
    return movie;
}

console.log(movie);
console.log(theNotebook());
console.log(movie);
console.log(song);

var num = 100
console.log(typeof num);