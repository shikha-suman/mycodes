"use strict";

import display_message from 'messageModule.js'
display_message()


// compile-modules convert -I scripts -o out Messagemodule.js 
//    consumeModule.js -format commonjs