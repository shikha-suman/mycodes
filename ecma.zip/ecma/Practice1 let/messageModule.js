"use strict";

function display_message() {
    console.log("Hello World")
}
export default display_message