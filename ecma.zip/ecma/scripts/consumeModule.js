"use strict";

import display_message from 'messageModule.js'
display_message()