// Let's try to print the value of __filename
// __filename represents the filename of the code being executed. This is the resolved absolute path of this code file.

console.log(__filename);


/* setInterval  global function*/
function printHello() {
    console.log("Hello, World!");
}
// Now call above function after 2 seconds
setInterval(printHello, 2000);