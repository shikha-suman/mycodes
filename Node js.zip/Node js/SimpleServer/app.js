const http = require('http'); //including a module

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
    res.statusCode = 200; //200 means ok
    res.setHeader('Content-type', 'text/plain');
    res.end('Hello World!');
});

server.listen(port, hostname, () => {
    console.log('Server started on port ' + port);
})


//in cmd run---> node app