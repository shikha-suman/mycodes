const http = require('http'); //including a module
const fs = require('fs'); //file system module to load files

const hostname = '127.0.0.1';
const port = 3000;


//function to read file
fs.readFile('index.html', (err, html) => {
    if (err) {
        throw err;
    }

    const server = http.createServer((req, res) => {
        res.statusCode = 200; //200 means ok
        // res.setHeader('Content-type', 'text/plain');  this shows html in browser
        res.setHeader('Content-type', 'text/html');
        res.write(html);
        res.end();
    });

    server.listen(port, hostname, () => {
        console.log('Server started on port ' + port);
    })
});