// To import use require and store in local variable
// while importing modules don't include .js
var movies = require('./movies');
movies.mymovie();
movies.printSDF();
console.log(movies.favourite);

//run app.js to see result