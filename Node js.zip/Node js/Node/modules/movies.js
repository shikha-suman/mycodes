//method-1
module.exports = {
    printSDF: function() {
        console.log("This movie is exported");
    },
    //variables can also be exported
    favourite: "hello world"
};


//method-2
function printABC() {
    console.log("ABC -- YEYY");
}

//this is private function..i.e not exported
function printXYZ() {
    console.log("XYZ-- YEYY");
}

//What gets exported is determined by 'module.exports' variable
module.exports.mymovie = printABC;