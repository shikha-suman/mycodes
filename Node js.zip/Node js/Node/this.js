var Shikha = {
    printFirstName: function() {
        console.log("My name is shikha");
        console.log(this === Shikha);
    }
};
Shikha.printFirstName();

//default calling context is global

function doSomething() {
    console.log("\n I am a progammer");
    console.log(this === Shikha);
    console.log(this === global);

}

doSomething();