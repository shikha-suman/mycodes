//fs= file system module
//variable is same as module...here fs
var fs = require('fs');

//run it to see it creates a new file..i.e corn.txt 
fs.writeFileSync("corn.txt", "Corn is good");

//to read file
console.log(fs.readFileSync("corn.txt").toString());