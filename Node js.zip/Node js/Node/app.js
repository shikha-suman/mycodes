function placeOrder(orderNumber) {
    console.log("customer order:", orderNumber);



    cookAndDeliverFood(function() {
        console.log("delivered food order: ", orderNumber);
    });
}

//Simulate a 5 second operation
function cookAndDeliverFood(callback) {
    setTimeout(callback, 5000);
}

//Simulate users web request

placeOrder(1);
placeOrder(2);
placeOrder(3);
placeOrder(4);
placeOrder(5);
placeOrder(6);