var movies = require('./movies');
movies.favMovie = "The Notebook";
console.log("Suman's favorite movie is: " + movies.favMovie);