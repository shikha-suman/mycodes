module.exports = {
    favMovie: ""
};