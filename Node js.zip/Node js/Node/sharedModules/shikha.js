var movies = require('./movies');
console.log("Shikha's favorite movie is: " + movies.favMovie);