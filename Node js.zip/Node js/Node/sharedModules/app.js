require('./suman');
require('./shikha');

//order of require matters

//favMovie of suman is reflected as shikha's favMovie too