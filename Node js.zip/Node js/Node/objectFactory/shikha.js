var movies = require('./movies');

var shikhasMovies = movies();
shikhasMovies.favMovie = "3 idiots";
console.log("Shikha's favorite movie is: " + shikhasMovies.favMovie);