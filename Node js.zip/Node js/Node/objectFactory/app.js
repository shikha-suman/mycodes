require('./suman');
require('./shikha');

//each module has own custom copy.