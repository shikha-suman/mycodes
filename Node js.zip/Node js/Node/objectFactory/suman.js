var movies = require('./movies');
//create variable
var sumansMovies = movies();
sumansMovies.favMovie = "The Notebook";
console.log("Suman's favorite movie is: " + sumansMovies.favMovie);