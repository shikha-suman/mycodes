function User() {
    this.name = "";
    this.life = 100;
    this.giveLife = function giveLife(targetPlayer) {
        targetPlayer.life += 1;
        console.log(this.name + " gave 1 life to " + targetPlayer.name);
    }
}

var Shikha = new User();
var Suman = new User();

//set name of users
Shikha.name = "Shikha";
Suman.name = "Suman";

Shikha.giveLife(Suman);
console.log("Shikha: " + Shikha.life);
console.log("Suman: " + Suman.life);


//prototype to add additional functions like uppercut to  objects
User.prototype.uppercut = function uppercut(targetPlayer) {
    targetPlayer.life -= 3;
    console.log(this.name + " just uppercutted " + targetPlayer.name);
};

Suman.uppercut(Shikha);
console.log("Shikha: " + Shikha.life);
console.log("Suman: " + Suman.life);

//add properties to objects by prototyping

User.prototype.magic = 60;
console.log(Shikha.magic);
console.log(Suman.magic);