//in node everything is reference

//object
var Shikha = {
    favFood: "dosa",
    favMovie: "abc"
};


//Person is reference i.e properties of original object are replaced

var Person = Shikha;
Person.favFoood = 'salad';
console.log(Shikha.favFood);

//difference between == and ===

//== checks values only
console.log(20 == "20"); //true  

//===checks values and type
console.log(20 === "20"); //false