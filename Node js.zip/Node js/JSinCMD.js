function greeting()
console.log('helloooo');