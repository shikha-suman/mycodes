var message = "Hello World"
 console.log(message);

//functions
 class Greeting {
    greet():void {
        console.log("Hello Welcome!")
    }
}

var obj=new Greeting();
 obj.greet();


 //variable declaration


 var name1:string = "shikha"
var mynum:number = 100
console.log(name1) 
console.log(mynum) 

//rest parameters

function addNumbers(...nums:number[]) {  
   var i;   
   var sum:number = 0; 
   
   for(i = 0;i<nums.length;i++) { 
      sum = sum + nums[i]; 
   } 
   console.log("sum of the numbers",sum) 
} 
addNumbers(1,2,3) 
addNumbers(10,20,30,40,50,60)


//optional parameters

function disp_details(id:number,name:string,mail_id?:string) { 
   console.log("ID:", id); 
   console.log("Name",name); 
   
   if(mail_id!=undefined)  
   console.log("Email Id",mail_id); 
}
disp_details(123,"SUMAN");
disp_details(111,"Shikhaa","shikha@suman.com");


//default parameters

function calculate_discount(price:number,rate:number = 0.50) { 
   var discount = price * rate; 
   console.log("Discount Amount: ",discount); 
} 
calculate_discount(1000) 
calculate_discount(1000,0.30)


//anonymous function


var msg = function() { 
   return "welcome to webtech";  
} 
console.log(msg())


//lambda expressions


var myvar = (x:number)=>10 + x 
console.log(myvar(100))   


//tuples

var mytuple = [10,"Hello"];
console.log(mytuple[0]) 
console.log(mytuple[1])


//union


var val:string|number 
val = 12 
console.log("numeric value of val "+val) 
val = "This is a string" 
console.log("string value of val "+val)


//array


var myarr:string[]; 
myarr = ["1","2","3","4"] 
console.log(myarr[0]); 
console.log(myarr[1]);


//for-in loop

var j:any; 
var nums:number[] = [1001,1002,1003,1004] 

for(j in nums) { 
   console.log(nums[j]) 
} 


//interfaces


interface IPerson { 
   firstName:string, 
   lastName:string, 
   sayHi: ()=>string 
} 

var customer:IPerson = { 
   firstName:"ankita",
   lastName:"gupta", 
   sayHi: ():string =>{return "Hi there"} 
} 

console.log("Customer Object ") 
console.log(customer.firstName) 
console.log(customer.lastName) 
console.log(customer.sayHi())  

var employee:IPerson = { 
   firstName:"shikha",
   lastName:"suman", 
   sayHi: ():string =>{return "Hello!!!"} 
} 
  
console.log("Employee  Object ")
console.log(employee.firstName) 
console.log(employee.lastName)


//inheritence


class Root { 
   str:string; 
} 

class Child extends Root {} 
class Leaf extends Child {}  

var h1 = new Leaf(); 
h1.str ="hello" 
console.log(h1.str)


//Object

var person = { 
   firstname:"puja", 
   lastname:"srivastava" 
}; 
//access the object values 
console.log(person.firstname) 
console.log(person.lastname)