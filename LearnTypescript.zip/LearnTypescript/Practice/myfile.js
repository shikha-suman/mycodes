var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var message = "Hello World";
console.log(message);
//functions
var Greeting = (function () {
    function Greeting() {
    }
    Greeting.prototype.greet = function () {
        console.log("Hello Welcome!");
    };
    return Greeting;
}());
var obj = new Greeting();
obj.greet();
//variable declaration
var name1 = "shikha";
var mynum = 100;
console.log(name1);
console.log(mynum);
//rest parameters
function addNumbers() {
    var nums = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        nums[_i] = arguments[_i];
    }
    var i;
    var sum = 0;
    for (i = 0; i < nums.length; i++) {
        sum = sum + nums[i];
    }
    console.log("sum of the numbers", sum);
}
addNumbers(1, 2, 3);
addNumbers(10, 20, 30, 40, 50, 60);
//optional parameters
function disp_details(id, name, mail_id) {
    console.log("ID:", id);
    console.log("Name", name);
    if (mail_id != undefined)
        console.log("Email Id", mail_id);
}
disp_details(123, "SUMAN");
disp_details(111, "Shikhaa", "shikha@suman.com");
//default parameters
function calculate_discount(price, rate) {
    if (rate === void 0) { rate = 0.50; }
    var discount = price * rate;
    console.log("Discount Amount: ", discount);
}
calculate_discount(1000);
calculate_discount(1000, 0.30);
//anonymous function
var msg = function () {
    return "welcome to webtech";
};
console.log(msg());
//lambda expressions
var myvar = function (x) { return 10 + x; };
console.log(myvar(100));
//tuples
var mytuple = [10, "Hello"];
console.log(mytuple[0]);
console.log(mytuple[1]);
//union
var val;
val = 12;
console.log("numeric value of val " + val);
val = "This is a string";
console.log("string value of val " + val);
//array
var myarr;
myarr = ["1", "2", "3", "4"];
console.log(myarr[0]);
console.log(myarr[1]);
//for-in loop
var j;
var nums = [1001, 1002, 1003, 1004];
for (j in nums) {
    console.log(nums[j]);
}
var customer = {
    firstName: "ankita",
    lastName: "gupta",
    sayHi: function () { return "Hi there"; }
};
console.log("Customer Object ");
console.log(customer.firstName);
console.log(customer.lastName);
console.log(customer.sayHi());
var employee = {
    firstName: "shikha",
    lastName: "suman",
    sayHi: function () { return "Hello!!!"; }
};
console.log("Employee  Object ");
console.log(employee.firstName);
console.log(employee.lastName);
//inheritence
var Root = (function () {
    function Root() {
    }
    return Root;
}());
var Child = (function (_super) {
    __extends(Child, _super);
    function Child() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Child;
}(Root));
var Leaf = (function (_super) {
    __extends(Leaf, _super);
    function Leaf() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Leaf;
}(Child));
var h1 = new Leaf();
h1.str = "hello";
console.log(h1.str);
//Object
var person = {
    firstname: "puja",
    lastname: "srivastava"
};
//access the object values 
console.log(person.firstname);
console.log(person.lastname);
