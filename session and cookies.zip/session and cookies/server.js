var express = require('express');
var app = express();
var port = process.env.PORT || 8080;

var cookieParser = require('cookie-parser');
var session = require('express-session');
// var morgan = require('morgan'); //for login

// app.use(morgan('dev'));
app.use(cookieParser());
app.use(session({
    secret: 'anystringoftext', //for encrypting datas
    saveUninitialized: true, //save to db  evenif no changes in session
    resave: true

}));


app.use('/', function(req, res) {
    res.send('Our Express program with cookie!');
    console.log(req.cookies);
    console.log('================');
    console.log(req.session);
});

app.listen(port);
console.log('Server running on port: ' + port);

//in console we have: session id ; signature used to sign cookie for authentication to the server