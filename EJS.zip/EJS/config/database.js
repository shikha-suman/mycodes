module.exports = {
    'url': 'webtechdevops.centralindia.cloudapp.azure.com:51003/shikhaDB'
}