//create obj 

var obj = {};
var val = 'value';
obj[val] = 'new value';
console.log(obj[val]);