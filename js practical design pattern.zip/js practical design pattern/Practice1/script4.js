//method3
var task = {
    title: 'My third method',
    description: 'My description'
};


task.toString = function() {
    return this.title + ' ' + this.description;
}


console.log(task.toString());