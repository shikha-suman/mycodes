//method2
var task1 = {};

task1.title = 'My second method ';
task1.description = 'My description';

console.log(task1.title);