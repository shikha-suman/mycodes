//create obj
var obj1 = {};
obj.myname = 'shikha';
console.log(obj.myname);