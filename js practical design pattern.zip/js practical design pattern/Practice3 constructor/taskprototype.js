var Taskk = function(name) {
        this.name = name;
        this.completed = false;


        this.complete = function() {
            console.log('completing task: ' + this.name);
            this.completed = true;
        }

        this.save = function() {
            console.log('saving Task: ' + this.name);
        }
    }
    //using prototype--everytime we crete new copy of Task we are not creating copy of "complete" function
Taskk.prototype.complete = function() {
    console.log('completing task: ' + this.name);
    this.completed = true;
};

var task1 = new Taskk('create a demo for constructor');
var task2 = new Taskk('create a demo for modules');
var task3 = new Taskk('create a demo for singleton');
var task4 = new Taskk('create a demo for prototypes');

task1.complete();
task2.save();
task3.save();
task4.save();