var task = {
    title: 'My title',
    description: 'My description'
};

Object.defineProperty(task, 'toString', {
    value: function() {
        return this.title + ' ' + this.description;
    },
    writable: false,
    enumerable: false,

    configurable: true

});

var urgentTask = Object.create(task);//inheritence using object.create
//so urgenttask is also task
Object.defineProperty(urgentTask, 'toString', {
    value: function() {
        return this.title + ' is urgent';
    },
    writable: false,
    enumerable: false,

    configurable: false

});


console.log(urgentTask.toString());