var task = {
    title: 'My title',
    description: 'My description'
};

Object.defineProperty(task, 'toString', {
    value: function() {
        return this.title + ' ' + this.description;
    },
    writable: false, //can't overwite 'toString' if it is false
    enumerable: false, //hides "toSring"...shows only title and description
    //enumerable: true,

    configurable: true //can redefine the enumerable if this is true.


});
//toString will again come as following code executes....as configurable is true.
Object.defineProperty(task, 'toString', {
    enumerable: true,
});

task.toString = 'hi'; //ignores this
//writable is used bacause we don't want to define "toString" variable in the program
//coz "toString' won't be function any more. we use writable coz we don't want to overwrite toString

console.log(Object.keys(task)); //displays as array
console.log(task);