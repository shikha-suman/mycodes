alert("Hey you! I created this alert box!!!");
var Name = prompt("What's ur name???");

var gotname = false;
while (gotname == false) {
    confirm(Name + "! Do you want to have pizza today???");
    var pizzaName = prompt("Name d pizza u wanna have")
    if (confirm("Are u sure u want to have " + pizzaName + "???")) {
        alert(pizzaName + " yeyyy!!!");
        gotname = true;
    }
}