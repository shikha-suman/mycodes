var Tony = {
    firstname: 'shikha',
    lastname: 'suman',
    address: {
        street: 'n/14',
        city: 'patna',
        state: 'bihar'
    }
};
console.log(Tony);


function greet(person) {
    console.log('Hi ' + person.firstname);
}

greet(Tony); //first output

greet({
    firstname: 'sweta',
    lastname: 'surbhi'
})

Tony.address2 = {
    street: '333 f'
}