//same variable name but different contexts


function b() {
    var myVar;
    console.log(myVar);
}

function a() {
    var myVar = 2;
    console.log(myVar);
    b();
}

var myVar = 1;
console.log(myVar); //first result
a();
console.log(myVar); //this is last result