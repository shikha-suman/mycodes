var c = 'Hello';

function b() {
    console.log('called b!');
}
//in console write a;
b();
console.log(c);