var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require('mongoose');




app.use(function(req, res, next) {   
    res.header("Access-Control-Allow-Origin", "*");    //setting the headers
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept,Authorization");   
    next();
});



//grab the Project model
var Project = require('./project.model');

var db = 'webtechdevops.centralindia.cloudapp.azure.com:51003/shikhaDB';
mongoose.connect(db);


var port = 8080;

app.listen(port, function() {
    console.log('app listening on port ' + port);
})


/*CREATE*/

// var newProject1 = Project({
//     ProjectName: 'Project 1',
//     ProjectId: '1',
//     NexusId: 'N111',
//     IgAccount: 'IG90000',
//     BidOwner: 'mindtree',
//     BidMinds: 'xyz'
// });
// // save the project
// newProject1.save(function(err) {
//     if (err) throw err;

//     console.log('New project 1 created!');
// });

// var newProject2 = Project({
//     ProjectName: 'Project 2',
//     ProjectId: '2',
//     NexusId: 'N112',
//     IgAccount: 'IG90001',
//     BidOwner: 'mindtree_chennai',
//     BidMinds: 'shikha'
// });
// // save the project
// newProject2.save(function(err) {
//     if (err) throw err;

//     console.log('New project 2 created!');
// });


// var newProject3 = Project({
//     ProjectName: 'Project 3',
//     ProjectId: '3',
//     NexusId: 'N113',
//     IgAccount: 'IG90002',
//     BidOwner: 'mindtree_bangalore',
//     BidMinds: 'suman'
// });
// // save the project
// newProject3.save(function(err) {
//     if (err) throw err;

//     console.log('New project 3 created!');
// });


// var newProject4 = Project({
//     ProjectName: 'Project 4',
//     ProjectId: '4',
//     NexusId: 'N114',
//     IgAccount: 'IG90003',
//     BidOwner: 'mindtree_pune',
//     BidMinds: 'ankita'
// });
// // save the project
// newProject4.save(function(err) {
//     if (err) throw err;

//     console.log('New project 4 created!');
// });


// var newProject5 = Project({
//     ProjectName: 'Project 5',
//     ProjectId: '5',
//     NexusId: 'N115',
//     IgAccount: 'IG90004',
//     BidOwner: 'mindtree_bbsr',
//     BidMinds: 'alekhya'
// });
// // save the project
// newProject5.save(function(err) {
//     if (err) throw err;

//     console.log('New project 5 created!');
// });




/* READ */

// get all projects i.e reading 

// Project.find({}, function(err, projects) {
//     if (err) throw err;

//     // object of all projects
//     console.log(projects);
// });


// // get the project by nexus id
// Project.find({ NexusId: 'N115' }, function(err, project) {
//     if (err) throw err;

//     // object of the project
//     console.log(project);
// });


// // get book with ID 
// Project.findById("58d0f2c6091bbb2be0f2807e", function(err, project) {
//     if (err) throw err;

//     // show one project
//     console.log(project);
// });



/* UPDATE */



// // get project with ID and update ig account using save
// Project.findById("58d0f2c6091bbb2be0f2807e", function(err, project) {
//     if (err) throw err;

//     // change the project 
//     project.IgAccount = 'IG65776';

//     // save the project
//     project.save(function(err) {
//         if (err) throw err;

//         console.log('Project successfully updated!');
//     });

// });


// // find the project with id and update
// // update bid minds with id
// Project.findByIdAndUpdate("58d0c7509b85871cf44e58b7", { BidMinds: 'tarique' }, function(err, project) {
//     if (err) throw err;

//     // we have the updated project returned to us
//     console.log(project);
// });





// // update project name by NEXUS ID
// Project.findOneAndUpdate({ NexusId: 'N115' }, { ProjectName: "my projajkdhkjafhk" }, function(err, project) {
//     if (err) throw err;

//     // we have the updated project returned to us
//     console.log(project);
// });

/* DELETE */
// // get the PROJECT and delete all projects
// Project.find({ NexusId: 'N111' }, function(err, project) {
//     if (err) throw err;

//     // delete project
//     Project.remove(function(err) {
//         if (err) throw err;

//         console.log('Project successfully deleted!');
//     });
// });



// // find the project with nexus id and delete one project
// Project.findOneAndRemove({ NexusId: 'N111' }, function(err) {
//     if (err) throw err;

//     // we have deleted the book
//     console.log('Book deleted!');
// });


// // find the book by id and delete
// Project.findByIdAndRemove("58d0cba39d67862238241ff0", function(err) {
//     if (err) throw err;

//     // we have deleted the book
//     console.log('Project deleted!');
// });



app.get('/', function(req, res) {
    res.send('hello qep');
});


// app.listen(8080, function(){
//     console.log('running on ur port');
// });

var projectRouter = express.Router();
projectRouter.route('/Project')
    .get(function(req, res) {
        var responseJson = { hello: "this is my api" };
        res.json(responseJson);
    });


app.use('/api', projectRouter);