// 'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var ProjectSchema = new Schema({
    ProjectName: String,
    ProjectId: String,
    NexusId: String,
    IgAccount: String,
    BidOwner: String,
    BidMinds: String


});

module.exports = mongoose.model('Project', ProjectSchema);