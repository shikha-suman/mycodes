//create a reference to express
var express = require('express');
mongoose = require('mongoose');
bodyParser = require('body-parser');

var db = mongoose.connect('webtechdevops.centralindia.cloudapp.azure.com:51003/shikhaDB');

mongoose.connection.on('connected', () => {
    console.log(db);
});

var Book = require('./models/bookModel');
//create instance of express
var app = express();
//set port...environment port or 3000
var port = process.env.PORT || 3000;

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


var bookRouter = express.Router();

// bookPush = {
//     title: "shikha",
//     author: "hhhhh",
//     genre: "dummy",
//     read: "kkkk"
// }

// var myBookpush = new Book(bookPush);


// myBookpush.save(function(err, result) {
//     if (err) {
//         console.log("cant insert");

//     }
//     console.log("insertd data");
//     console.log("--------------", result);
// })


bookRouter.route('/Books')
    .post(function(req, res) {
        var book = new Book(req.body);
        console.log(book);
        res.send(book);


    })
    .get(function(req, res) {
        // var responseJson = {
        //     hello: "this is my api"
        // };

        var query = {}; //empty query
        if (req.query.genre) {
            query.genre = req.query.genre;
        }
        Book.find(query, function(err, books) {
            if (err)
            // console.log(err)
                res.status(500).send(err);
            else
                res.json(books);
        });
    });

app.use('/api', bookRouter);
//go to localhost:8000/api/books





bookRouter.route('/Books/:bookId')
    .get(function(req, res) {

        Book.findById(req.params.bookId, function(err, book) {
            if (err)
                res.status(500).send(err);
            else
                res.json(book);
        });
    });

app.use('/api', bookRouter);









//root is /
//req is request by client...res is responce by server
app.get('/', function(req, res) {

    res.send('wecome to my API!!!...yesss..yooo');
});

//function is callback function
app.listen(port, function() {
    console.log('running on PORT: ' + port);
});